import functools
import operator

def faktorPrima(n):
    faktorlist = []
    n_ori = n
    st = True
    while st :
        for i in range(2, n+1):
            if n/i == int(n/i):
                faktorlist.append(i)
                n = int(n/i)
                break
        if functools.reduce(operator.mul, faktorlist, 1) == n_ori:
            st = False
    return faktorlist

print (faktorPrima(10))
print (faktorPrima(120))
print (faktorPrima(19))
