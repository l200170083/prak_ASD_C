def apakahTerkandung(a,b):
    return a in b

h = "do"
k = "Indonesia tanah air beta"
print (apakahTerkandung(h, k))
print (apakahTerkandung("pusaka", k))
